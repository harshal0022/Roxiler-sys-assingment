const monthSelector = document.getElementById('month-selector');
const searchBox = document.getElementById('search-box');
const transactionData = document.getElementById('transaction-data');
const prevButton = document.getElementById('previous-button');
const nextButton = document.getElementById('next-button');
const salesTotal = document.getElementById('sales-total');
const soldCount = document.getElementById('sold-count');
const unsoldCount = document.getElementById('unsold-count');

let currentPage = 1;
const recordsPerPage = 10;

// Fetch and render transactions
const loadTransactions = async () => {
    const month = monthSelector.value;
    const searchQuery = searchBox.value.trim();
    const apiUrl = `http://127.0.0.1:5000/transactions?month=${month}&search=${searchQuery}&page=${currentPage}&per_page=${recordsPerPage}`;
    
    const response = await fetch(apiUrl);
    const data = await response.json();

    transactionData.innerHTML = ''; // Clear previous data

    data.transactions.forEach((trans) => {
        const row = document.createElement('tr');
        row.innerHTML = `
            <td>${trans.id}</td>
            <td>${trans.product_name}</td>
            <td>${trans.transaction_amount}</td>
            <td>${trans.transaction_date}</td>
            <td>${trans.category}</td>
        `;
        transactionData.appendChild(row);
    });
};

// Fetch and render statistics
const loadStatistics = async () => {
    const month = monthSelector.value;
    const statsUrl = `http://127.0.0.1:5000/statistics?month=${month}`;
    
    const response = await fetch(statsUrl);
    const stats = await response.json();

    salesTotal.textContent = stats.total_sales;
    soldCount.textContent = stats.total_items_sold;
    unsoldCount.textContent = stats.total_items_not_sold;
};

// Fetch and render bar chart
const loadBarChart = async () => {
    const month = monthSelector.value;
    const chartUrl = `http://127.0.0.1:5000/bar-chart?month=${month}`;
    
    const response = await fetch(chartUrl);
    const chartData = await response.json();

    const ctx = document.getElementById('price-bar-chart').getContext('2d');

    new Chart(ctx, {
        type: 'bar',
        data: {
            labels: Object.keys(chartData),
            datasets: [{
                label: 'Items per Price Range',
                data: Object.values(chartData),
                backgroundColor: 'rgba(0, 123, 255, 0.5)',
                borderColor: 'rgba(0, 123, 255, 1)',
                borderWidth: 1
            }]
        },
        options: {
            scales: {
                y: {
                    beginAtZero: true
                }
            }
        }
    });
};

// Event Listeners
monthSelector.addEventListener('change', () => {
    currentPage = 1;
    loadTransactions();
    loadStatistics();
    loadBarChart();
});

searchBox.addEventListener('input', () => {
    currentPage = 1;
    loadTransactions();
});

prevButton.addEventListener('click', () => {
    if (currentPage > 1) {
        currentPage--;
        loadTransactions();
    }
});

nextButton.addEventListener('click', () => {
    currentPage++;
    loadTransactions();
});

// Initial Load
window.onload = () => {
    loadTransactions();
    loadStatistics();
    loadBarChart();
};
