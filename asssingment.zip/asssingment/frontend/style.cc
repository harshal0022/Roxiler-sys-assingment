body {
    font-family: 'Segoe UI', sans-serif;
    margin: 0;
    padding: 20px;
}

.main-container {
    width: 90%;
    margin: auto;
    max-width: 1200px;
}

h1, h3 {
    text-align: center;
    margin: 20px 0;
}

.table-wrapper {
    margin-top: 20px;
}

table {
    width: 100%;
    border-collapse: collapse;
}

th, td {
    padding: 10px;
    border: 1px solid #ccc;
    text-align: left;
}

.pagination-buttons {
    display: flex;
    justify-content: space-between;
    margin-top: 10px;
}

.stats-section {
    display: flex;
    justify-content: space-around;
    margin-top: 30px;
}

.stats-item {
    background-color: #f8f8f8;
    padding: 20px;
    border-radius: 8px;
}

.chart-section {
    margin-top: 30px;
}
