from flask import Flask, jsonify, request
from flask_sqlalchemy import SQLAlchemy
import requests
from datetime import datetime

app = Flask(__name__)
app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:///transactions.db'
app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False
db = SQLAlchemy(app)

# Transaction Model
class Transaction(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    product_name = db.Column(db.String(100))
    description = db.Column(db.String(200))
    transaction_amount = db.Column(db.Float)
    transaction_date = db.Column(db.Date)
    category = db.Column(db.String(50))
    is_sold = db.Column(db.Boolean)

# Initialize database and seed with data from third-party API
def initialize_database():
    response = requests.get("https://s3.amazonaws.com/roxiler.com/product_transaction.json")
    transactions = response.json()

    for transaction in transactions:
        # Parse date and prepare data
        date_of_sale = datetime.strptime(transaction['dateOfSale'], '%Y-%m-%dT%H:%M:%S')
        is_sold = transaction['sold']
        db.session.add(Transaction(
            product_name=transaction['title'],
            description=transaction['description'],
            transaction_amount=transaction['price'],
            transaction_date=date_of_sale,
            category=transaction['category'],
            is_sold=is_sold
        ))
    db.session.commit()

# Route to fetch paginated transactions with search
@app.route('/transactions', methods=['GET'])
def get_transactions():
    month = request.args.get('month')
    search = request.args.get('search', '').lower()
    page = int(request.args.get('page', 1))
    per_page = int(request.args.get('per_page', 10))
    
    # Filter by month and search parameters
    query = Transaction.query.filter(db.extract('month', Transaction.transaction_date) == get_month_number(month))
    if search:
        query = query.filter(
            (Transaction.product_name.ilike(f'%{search}%')) | 
            (Transaction.description.ilike(f'%{search}%')) | 
            (Transaction.transaction_amount.ilike(f'%{search}%'))
        )
    
    # Pagination
    transactions = query.paginate(page=page, per_page=per_page, error_out=False)
    result = [{
        'id': trans.id,
        'product_name': trans.product_name,
        'description': trans.description,
        'transaction_amount': trans.transaction_amount,
        'transaction_date': trans.transaction_date.strftime('%Y-%m-%d'),
        'category': trans.category,
        'is_sold': trans.is_sold
    } for trans in transactions.items]
    
    return jsonify({'transactions': result, 'total': transactions.total})

# Route to fetch monthly statistics
@app.route('/statistics', methods=['GET'])
def get_statistics():
    month = request.args.get('month')
    query = Transaction.query.filter(db.extract('month', Transaction.transaction_date) == get_month_number(month))

    total_sales = sum(t.transaction_amount for t in query.all() if t.is_sold)
    total_items_sold = query.filter_by(is_sold=True).count()
    total_items_not_sold = query.filter_by(is_sold=False).count()

    return jsonify({
        'total_sales': total_sales,
        'total_items_sold': total_items_sold,
        'total_items_not_sold': total_items_not_sold
    })

# Route to fetch data for the bar chart (price ranges)
@app.route('/bar-chart', methods=['GET'])
def get_bar_chart():
    month = request.args.get('month')
    query = Transaction.query.filter(db.extract('month', Transaction.transaction_date) == get_month_number(month))

    price_ranges = {
        '0-100': 0, '101-200': 0, '201-300': 0, '301-400': 0,
        '401-500': 0, '501-600': 0, '601-700': 0, '701-800': 0,
        '801-900': 0, '901+': 0
    }

    for t in query.all():
        price = t.transaction_amount
        if price <= 100:
            price_ranges['0-100'] += 1
        elif 101 <= price <= 200:
            price_ranges['101-200'] += 1
        # Continue the logic for other price ranges...
        elif price >= 901:
            price_ranges['901+'] += 1

    return jsonify(price_ranges)

# Route to fetch pie chart data (categories and item count)
@app.route('/pie-chart', methods=['GET'])
def get_pie_chart():
    month = request.args.get('month')
    query = Transaction.query.filter(db.extract('month', Transaction.transaction_date) == get_month_number(month))

    category_count = {}
    for t in query.all():
        if t.category in category_count:
            category_count[t.category] += 1
        else:
            category_count[t.category] = 1

    return jsonify(category_count)

# Helper function to convert month name to number
def get_month_number(month):
    months = {
        'January': 1, 'February': 2, 'March': 3, 'April': 4, 'May': 5, 'June': 6,
        'July': 7, 'August': 8, 'September': 9, 'October': 10, 'November': 11, 'December': 12
    }
    return months.get(month)

if __name__ == '__main__':
    with app.app_context():
        db.create_all()
        # Initialize only if database is empty
        if Transaction.query.count() == 0:
            initialize_database()
    app.run(debug=True)
